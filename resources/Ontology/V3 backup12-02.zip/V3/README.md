# CloudSocket-Ontology
This repository contains all the ontologies developed during the Cloudsocket project
